To build the file run 
g++ -g ./code.cpp -std=c++17 -o ./code `pkg-config --cflags --libs opencv4`
To run the build file run
./code
